# VaultFlow Plaid Backend

This backend adds the Plaid routes that the VaultFlow HTML app expects.

## Routes

- `POST /plaid/health`
- `POST /plaid/create-link-token`
- `POST /plaid/create-income-link-token`
- `POST /plaid/income/payroll`
- `POST /plaid/exchange-token`
- `POST /plaid/transactions`
- `POST /plaid/webhook`
- `POST /bank/transfer`
- `POST /market/signals`
- `POST /trading/connect`
- `POST /trading/order`

## Local Setup

1. Copy `.env.example` to `.env`.
2. Put your Plaid Sandbox values in `.env`.
3. Install and run:

```bash
npm install
npm start
```

4. Check:

```bash
curl -X POST http://localhost:3000/plaid/health \
  -H "Content-Type: application/json" \
  -d '{"user_id":"test"}'
```

## Railway Setup

Deploy this `backend` folder to Railway and add these Variables:

```env
PLAID_CLIENT_ID=your_client_id
PLAID_SECRET=your_sandbox_secret
PLAID_ENV=sandbox
PLAID_PRODUCTS=auth,transactions,investments
PLAID_COUNTRY_CODES=US
PLAID_CLIENT_NAME=VaultFlow
PLAID_BANK_INCOME_DAYS=120
CORS_ORIGIN=http://127.0.0.1:8765,http://localhost:8765,https://your-domain.com
PLAID_WEBHOOK_URL=https://your-railway-domain.up.railway.app/plaid/webhook
ENABLE_TRANSFER=false
OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-4o-mini
ALPACA_KEY_ID=your_alpaca_key_id
ALPACA_SECRET_KEY=your_alpaca_secret_key
ALPACA_DATA_FEED=iex
ALPACA_TRADING_BASE_URL=https://paper-api.alpaca.markets
ENABLE_ALPACA_PAPER_ORDERS=false
```

Important:

- `PLAID_CLIENT_ID` must be the Plaid Client ID, not the secret.
- `PLAID_SECRET` must match `PLAID_ENV`. For `PLAID_ENV=sandbox`, use the Plaid Sandbox secret.
- ADP/payroll runs through the separate Plaid Income route `/plaid/create-income-link-token`. Keep normal bank products in `PLAID_PRODUCTS`; do not add `income_verification` to the default bank Link route.
- Alpaca keys belong only in Railway. Use the paper base URL first; keep `ENABLE_ALPACA_PAPER_ORDERS=false` until you intentionally want the backend to submit paper orders.
- After changing Railway Variables, redeploy the backend. Saving variables alone may not update the running service.

After deploy, both checks should work. The health route should exist:

```bash
curl -X POST https://your-railway-domain.up.railway.app/plaid/health \
  -H "Content-Type: application/json" \
  -d '{"user_id":"test"}'
```

Then the Link token route should return a `link_token`:

```bash
curl -X POST https://your-railway-domain.up.railway.app/plaid/create-link-token \
  -H "Content-Type: application/json" \
  -d '{"user_id":"test"}'
```

The ADP/payroll Income route should also return a `link_token`:

```bash
curl -X POST https://your-railway-domain.up.railway.app/plaid/create-income-link-token \
  -H "Content-Type: application/json" \
  -d '{"user_id":"test","income_source_types":["payroll"]}'
```

If `/plaid/health` returns `Not Found`, Railway is running an older backend build. Redeploy this `backend` folder.

If `/plaid/create-link-token` says `invalid client_id or secret provided`, the deployed service is reachable but the Plaid Client ID and Secret pair is wrong or from a different Plaid environment.

## Important Safety Notes

- Do not put `PLAID_SECRET` in the HTML frontend.
- Do not put `OPENAI_API_KEY` in the HTML frontend. The AI chat must call the backend.
- This demo backend stores bank sessions in memory. Use a database and encryption before real production users.
- Real auto-transfer is intentionally disabled. Enable money movement only after Plaid Transfer approval or after connecting a compliant ACH processor.
