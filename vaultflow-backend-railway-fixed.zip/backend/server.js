require('dotenv').config();

const crypto = require('crypto');
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

const PLAID_VERSION = process.env.PLAID_VERSION || '2020-09-14';
const PLAID_ENV = (process.env.PLAID_ENV || 'sandbox').toLowerCase();
const PLAID_BASE_URLS = {
  sandbox: 'https://sandbox.plaid.com',
  development: 'https://development.plaid.com',
  production: 'https://production.plaid.com'
};
const PLAID_BASE_URL = PLAID_BASE_URLS[PLAID_ENV] || PLAID_BASE_URLS.sandbox;

const CLIENT_NAME = process.env.PLAID_CLIENT_NAME || 'VaultFlow';
const PLAID_PRODUCTS = splitEnv(process.env.PLAID_PRODUCTS || 'auth,transactions,investments');
const PLAID_COUNTRY_CODES = splitEnv(process.env.PLAID_COUNTRY_CODES || 'US');
const CORS_ORIGINS = splitEnv(process.env.CORS_ORIGIN || '*');
const ALPACA_DATA_BASE_URL = process.env.ALPACA_DATA_BASE_URL || 'https://data.alpaca.markets';
const ALPACA_TRADING_BASE_URL = process.env.ALPACA_TRADING_BASE_URL || 'https://paper-api.alpaca.markets';
const ALPACA_DATA_FEED = process.env.ALPACA_DATA_FEED || 'iex';
const DOC_VAULT_SECRET = process.env.DOC_VAULT_ENCRYPTION_KEY || 'vaultflow-local-preview-document-vault-secret';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const OPENAI_BASE_URL = process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1';
const BUILD_VERSION = process.env.RAILWAY_GIT_COMMIT_SHA || process.env.SOURCE_VERSION || 'local';

// Demo storage only. Use a database + encryption before real production traffic.
const bankSessions = new Map();
const incomeUsers = new Map();
const webhookEvents = [];
const paperOrders = [];
const appStates = new Map();
const docVault = new Map();

app.use(express.json({ limit: '10mb' }));
app.use(cors({
  origin(origin, callback) {
    if (!origin || CORS_ORIGINS.includes('*') || CORS_ORIGINS.includes(origin)) {
      callback(null, true);
      return;
    }
    callback(new Error('Origin not allowed by CORS'));
  }
}));

app.get('/', (req, res) => {
  res.json({
    success: true,
    service: 'VaultFlow Plaid backend',
    build_version: BUILD_VERSION,
    plaid_env: PLAID_ENV,
    configured: plaidConfigured(),
    routes: [
      'GET /plaid/health',
      'POST /plaid/health',
      'POST /plaid/create-link-token',
      'POST /plaid/create-income-link-token',
      'POST /plaid/income/payroll',
      'POST /plaid/exchange-token',
      'POST /plaid/transactions',
      'POST /plaid/webhook',
      'POST /bank/transfer',
      'POST /investments/holdings',
      'POST /market/signals',
      'POST /trading/connect',
      'POST /trading/order',
      'POST /ai/health',
      'POST /ai/chat',
      'POST /live/readiness',
      'POST /vault/sign-url',
      'POST /vault/document',
      'GET /vault/document/:doc_id',
      'GET /app/state/:user_id',
      'POST /app/state'
    ]
  });
});

app.get('/plaid/health', plaidHealthHandler);
app.post('/plaid/health', plaidHealthHandler);

function plaidHealthHandler(req, res) {
  res.json(plaidHealthPayload());
}

app.post('/plaid/create-link-token', requirePlaidConfig, async (req, res) => {
  try {
    const userId = cleanUserId(req.body.user_id);
    const requestedProducts = normalizePlaidProducts(req.body.products);
    const payload = {
      client_name: CLIENT_NAME,
      language: 'en',
      country_codes: PLAID_COUNTRY_CODES,
      products: requestedProducts.length ? requestedProducts : PLAID_PRODUCTS,
      user: { client_user_id: userId }
    };

    if (process.env.PLAID_WEBHOOK_URL) {
      payload.webhook = process.env.PLAID_WEBHOOK_URL;
    }
    if (process.env.PLAID_REDIRECT_URI) {
      payload.redirect_uri = process.env.PLAID_REDIRECT_URI;
    }

    const data = await plaidPost('/link/token/create', payload);
    res.json({
      success: true,
      link_token: data.link_token,
      expiration: data.expiration,
      request_id: data.request_id
    });
  } catch (err) {
    sendPlaidError(res, err, 'Could not create Plaid Link token.');
  }
});

app.post('/plaid/create-income-link-token', requirePlaidConfig, async (req, res) => {
  try {
    const userId = cleanUserId(req.body.user_id);
    const incomeSourceTypes = normalizeIncomeSourceTypes(req.body.income_source_types || ['payroll']);
    const userToken = await getPlaidIncomeUserToken(userId);
    const incomeVerification = {
      income_source_types: incomeSourceTypes
    };

    if (incomeSourceTypes.includes('payroll')) {
      incomeVerification.payroll_income = {
        flow_types: ['payroll_digital_income']
      };
    }
    if (incomeSourceTypes.includes('bank')) {
      incomeVerification.bank_income = {
        days_requested: Number(process.env.PLAID_BANK_INCOME_DAYS || 120)
      };
    }

    const payload = {
      client_name: CLIENT_NAME,
      language: 'en',
      country_codes: PLAID_COUNTRY_CODES,
      products: ['income_verification'],
      user: { client_user_id: userId },
      user_token: userToken,
      income_verification: incomeVerification
    };

    if (process.env.PLAID_WEBHOOK_URL) {
      payload.webhook = process.env.PLAID_WEBHOOK_URL;
    }

    const data = await plaidPost('/link/token/create', payload);
    res.json({
      success: true,
      link_token: data.link_token,
      expiration: data.expiration,
      request_id: data.request_id,
      income_source_types: incomeSourceTypes,
      detail: 'Plaid Income Link token created. Use this for ADP/payroll provider connections, separate from normal bank Link.'
    });
  } catch (err) {
    sendPlaidError(res, err, 'Could not create Plaid Income Link token.');
  }
});

app.post('/plaid/exchange-token', requirePlaidConfig, async (req, res) => {
  try {
    const publicToken = String(req.body.public_token || '').trim();
    if (!publicToken) {
      res.status(400).json({ success: false, detail: 'public_token is required.' });
      return;
    }

    const data = await plaidPost('/item/public_token/exchange', {
      public_token: publicToken
    });

    const bankSessionId = `bank_${crypto.randomUUID()}`;
    bankSessions.set(bankSessionId, {
      accessToken: data.access_token,
      itemId: data.item_id,
      userId: cleanUserId(req.body.user_id),
      cursor: null,
      createdAt: new Date().toISOString()
    });

    res.json({
      success: true,
      // This is intentionally not Plaid's real access_token. The frontend keeps
      // an opaque session ID while the server keeps the secret Plaid token.
      access_token: bankSessionId,
      item_id: data.item_id,
      token_type: 'vaultflow_bank_session',
      request_id: data.request_id
    });
  } catch (err) {
    sendPlaidError(res, err, 'Could not exchange Plaid public token.');
  }
});

app.post('/plaid/transactions', requirePlaidConfig, async (req, res) => {
  try {
    const session = resolveBankSession(req.body.access_token);
    if (!session) {
      res.status(400).json({
        success: false,
        detail: 'A valid bank session is required. Reconnect Plaid Link.'
      });
      return;
    }

    const synced = await syncTransactions(session);
    const balance = await getBalance(session).catch(() => null);
    const paychecks = detectPaychecks(synced.transactions);

    res.json({
      success: true,
      item_id: session.itemId,
      cursor: session.cursor,
      transactions: synced.transactions,
      paychecks,
      balance,
      request_id: synced.request_id
    });
  } catch (err) {
    sendPlaidError(res, err, 'Could not sync Plaid transactions.');
  }
});

app.post('/plaid/income/payroll', requirePlaidConfig, async (req, res) => {
  try {
    const userId = cleanUserId(req.body.user_id);
    const saved = incomeUsers.get(userId);
    if (!saved || !saved.userToken) {
      res.status(400).json({
        success: false,
        detail: 'No Plaid Income user token found. Open ADP / payroll Link first.'
      });
      return;
    }
    const data = await plaidPost('/credit/payroll_income/get', {
      user_token: saved.userToken
    });
    res.json({
      success: true,
      source: 'plaid-payroll-income',
      items: data.items || [],
      request_id: data.request_id,
      detail: 'Payroll income fetched from Plaid Income for this backend user token.'
    });
  } catch (err) {
    sendPlaidError(res, err, 'Could not fetch Plaid Payroll Income.');
  }
});

app.post('/plaid/webhook', (req, res) => {
  webhookEvents.unshift({
    received_at: new Date().toISOString(),
    body: req.body
  });
  if (webhookEvents.length > 100) webhookEvents.pop();
  res.json({ success: true });
});

app.post('/bank/transfer', (req, res) => {
  if (process.env.ENABLE_TRANSFER !== 'true') {
    res.status(501).json({
      success: false,
      detail: 'Real transfers are disabled. Apply for Plaid Transfer or connect an ACH processor first.'
    });
    return;
  }

  res.status(501).json({
    success: false,
    detail: 'Transfer execution is intentionally not implemented until compliance, authorization, and processor approval are complete.'
  });
});

app.post('/investments/holdings', requirePlaidConfig, async (req, res) => {
  try {
    const session = resolveBankSession(req.body.access_token);
    if (!session) {
      res.status(400).json({
        success: false,
        detail: 'A valid Plaid investment session is required. Link an investment account first.'
      });
      return;
    }
    const data = await plaidPost('/investments/holdings/get', {
      access_token: session.accessToken
    });
    const securitiesById = new Map((data.securities || []).map((security) => [security.security_id, security]));
    const holdings = (data.holdings || []).map((holding) => {
      const security = securitiesById.get(holding.security_id) || {};
      const quantity = Number(holding.quantity || 0);
      const price = Number(security.close_price || security.latest_price || 0);
      const value = Number(holding.institution_value || 0) || quantity * price;
      return {
        account_id: holding.account_id,
        security_id: holding.security_id,
        name: security.name || security.ticker_symbol || 'Investment',
        symbol: security.ticker_symbol || security.cusip || 'N/A',
        type: security.type || 'security',
        quantity,
        price,
        value,
        cost_basis: Number(holding.cost_basis || 0)
      };
    });
    const totalValue = holdings.reduce((sum, holding) => sum + Number(holding.value || 0), 0);
    res.json({
      success: true,
      source: 'plaid-investments',
      accounts: data.accounts || [],
      holdings,
      total_value: totalValue,
      request_id: data.request_id
    });
  } catch (err) {
    sendPlaidError(res, err, 'Could not load Plaid investment holdings.');
  }
});

app.post('/market/signals', async (req, res) => {
  const symbols = normalizeMarketSymbols(req.body.symbols);
  const settings = normalizeSignalSettings(req.body.settings);
  const livePrices = alpacaConfigured() ? await fetchAlpacaPriceMap(symbols).catch(() => ({})) : {};
  const liveCount = Object.keys(livePrices).length;
  res.json({
    success: true,
    source: liveCount ? 'alpaca-market-data' : 'backend-local',
    detail: liveCount
      ? `Signals built from Alpaca ${ALPACA_DATA_FEED.toUpperCase()} daily bars where available.`
      : 'Rules-based signal engine fallback. Add Alpaca keys for live market bars.',
    generated_at: new Date().toISOString(),
    live_symbols: Object.keys(livePrices),
    signals: buildMarketSignals(symbols, settings, livePrices)
  });
});

app.post('/trading/connect', async (req, res) => {
  if (!alpacaConfigured()) {
    res.json({
      success: true,
      mode: 'paper-preview',
      live_trading_enabled: alpacaLiveTradingEnabled(),
      detail: 'Paper trading preview is connected. Add Alpaca keys to backend env vars for real paper account status.'
    });
    return;
  }
  try {
    const account = await alpacaTradingGet('/v2/account');
    const paperMode = alpacaPaperTradingBase();
    res.json({
      success: true,
      mode: paperMode ? 'alpaca-paper' : 'alpaca-live-guarded',
      status: account.status,
      buying_power: account.buying_power,
      paper_trading_base: paperMode,
      paper_orders_enabled: alpacaPaperOrdersEnabled(),
      live_trading_enabled: alpacaLiveTradingEnabled(),
      order_execution_enabled: alpacaOrderExecutionEnabled(),
      detail: alpacaOrderExecutionEnabled()
        ? (paperMode ? 'Alpaca paper account connected. Paper orders can be submitted after signal checks.' : 'Alpaca live endpoint connected and live trading flag is enabled. Confirm user authorization before every order.')
        : (paperMode ? 'Alpaca paper account connected. Set ENABLE_ALPACA_PAPER_ORDERS=true to submit paper orders.' : 'Alpaca account connected, but live trading remains guarded unless ENABLE_ALPACA_LIVE_TRADING=true.')
    });
  } catch (err) {
    res.status(err.status || 502).json({
      success: false,
      detail: err.message || 'Could not connect to Alpaca paper account.'
    });
  }
});

app.post('/trading/order', async (req, res) => {
  const symbol = normalizeMarketSymbols([req.body.symbol])[0];
  const notional = Number(req.body.notional || 0);
  const side = String(req.body.side || 'buy').toLowerCase();
  const signal = req.body.signal || {};
  const signalValue = String(signal.g || signal.signal || '').toUpperCase();

  if (!symbol || !notional || notional <= 0) {
    res.status(400).json({ success: false, detail: 'symbol and positive notional are required.' });
    return;
  }
  if (side !== 'buy' || signalValue !== 'BUY') {
    res.status(400).json({ success: false, detail: 'Order blocked by signal risk rules.' });
    return;
  }

  if (alpacaConfigured() && !alpacaPaperTradingBase() && !alpacaLiveTradingEnabled()) {
    res.status(403).json({
      success: false,
      detail: 'Live Alpaca trading is guarded off. Use the paper-api base URL, or explicitly set ENABLE_ALPACA_LIVE_TRADING=true after compliance and user authorization checks.'
    });
    return;
  }

  if (alpacaConfigured() && alpacaOrderExecutionEnabled()) {
    try {
      const order = await alpacaTradingPost('/v2/orders', {
        symbol,
        notional: String(notional),
        side: 'buy',
        type: 'market',
        time_in_force: 'day',
        client_order_id: `vf_${crypto.randomUUID().replace(/-/g, '').slice(0, 24)}`
      });
      res.json({
        success: true,
        mode: alpacaPaperTradingBase() ? 'alpaca-paper' : 'alpaca-live',
        order_id: order.id,
        status: order.status,
        symbol: order.symbol,
        notional: Number(order.notional || notional),
        submitted_at: order.submitted_at
      });
      return;
    } catch (err) {
      res.status(err.status || 502).json({
        success: false,
        detail: err.message || 'Alpaca paper order failed.'
      });
      return;
    }
  }

  const order = {
    order_id: `paper_${crypto.randomUUID()}`,
    symbol,
    side,
    notional,
    signal_confidence: Number(signal.confidence || 0),
    status: 'paper_submitted',
    created_at: new Date().toISOString()
  };
  paperOrders.unshift(order);
  if (paperOrders.length > 100) paperOrders.pop();
  res.json({
    success: true,
    mode: alpacaConfigured() ? 'paper-ledger-orders-disabled' : 'paper-preview',
    detail: alpacaConfigured()
      ? (alpacaPaperTradingBase() ? 'Paper order recorded locally. Set ENABLE_ALPACA_PAPER_ORDERS=true to submit to Alpaca paper.' : 'Order recorded locally. Set ENABLE_ALPACA_LIVE_TRADING=true only after production authorization to submit live Alpaca orders.')
      : 'Paper order recorded locally. Add Alpaca keys to submit to Alpaca paper.',
    ...order
  });
});

app.post('/ai/health', (req, res) => {
  res.json({
    success: openaiConfigured(),
    configured: openaiConfigured(),
    mode: openaiConfigured() ? 'openai-responses' : 'vaultflow-local-fallback',
    model: openaiConfigured() ? OPENAI_MODEL : null,
    detail: openaiConfigured()
      ? 'OpenAI API key is configured. VaultFlow Assistant can answer real questions through the backend.'
      : 'OPENAI_API_KEY is missing. VaultFlow Assistant will use local fallback answers until the backend is configured.'
  });
});

app.post('/ai/chat', async (req, res) => {
  const message = String(req.body.message || '').slice(0, 3000);
  if (!message.trim()) {
    res.status(400).json({ success: false, detail: 'message is required.' });
    return;
  }
  if (!openaiConfigured()) {
    res.json({
      success: true,
      mode: 'vaultflow-local-fallback',
      configured: false,
      answer: vaultflowAdvisorAnswer(message),
      detail: 'OPENAI_API_KEY is missing on the backend.'
    });
    return;
  }
  try {
    const answer = await askOpenAIAdvisor({
      message,
      history: Array.isArray(req.body.history) ? req.body.history : [],
      context: req.body.context || {}
    });
    res.json({
      success: true,
      mode: 'openai-responses',
      configured: true,
      model: OPENAI_MODEL,
      answer
    });
  } catch (err) {
    res.json({
      success: false,
      mode: 'openai-error',
      configured: true,
      detail: err.message || 'OpenAI request failed.',
      answer: vaultflowAdvisorAnswer(message)
    });
  }
});

app.post('/live/readiness', (req, res) => {
  res.json({
    success: true,
    service: 'VaultFlow live-readiness audit',
    plaid_configured: plaidConfigured(),
    plaid_env: PLAID_ENV,
    plaid_income_link_supported: true,
    plaid_income_users_cached: incomeUsers.size,
    transfer_enabled: process.env.ENABLE_TRANSFER === 'true',
    alpaca_configured: alpacaConfigured(),
    alpaca_paper_trading_base: alpacaPaperTradingBase(),
    alpaca_paper_orders_enabled: alpacaPaperOrdersEnabled(),
    alpaca_live_trading_enabled: alpacaLiveTradingEnabled(),
    alpaca_order_execution_enabled: alpacaOrderExecutionEnabled(),
    openai_configured: openaiConfigured(),
    openai_model: openaiConfigured() ? OPENAI_MODEL : null,
    doc_vault_key_configured: Boolean(process.env.DOC_VAULT_ENCRYPTION_KEY),
    doc_vault_signed_urls: true,
    cors_origins: CORS_ORIGINS,
    detail: 'Use this audit for configuration only. It does not move money or place trades.'
  });
});

app.post('/vault/sign-url', (req, res) => {
  const docId = cleanDocId(req.body.doc_id || `doc_${crypto.randomUUID()}`);
  const expires = Date.now() + 15 * 60 * 1000;
  const signature = signVaultUrl(docId, expires);
  const metadata = {
    doc_id: docId,
    filename: String(req.body.filename || 'vault-document').slice(0, 180),
    type: String(req.body.type || 'document').slice(0, 80),
    size: Number(req.body.size || 0),
    user_id: cleanUserId(req.body.user_id),
    created_at: new Date().toISOString()
  };
  docVault.set(docId, { metadata, encrypted: null });
  res.json({
    success: true,
    doc_id: docId,
    expires_at: new Date(expires).toISOString(),
    upload_url: `/vault/document?doc_id=${encodeURIComponent(docId)}&expires=${expires}&signature=${signature}`,
    download_url: `/vault/document/${encodeURIComponent(docId)}?expires=${expires}&signature=${signature}`,
    detail: 'Signed URLs expire in 15 minutes. Store files encrypted server-side before production.'
  });
});

app.post('/vault/document', (req, res) => {
  const docId = cleanDocId(req.query.doc_id || req.body.doc_id || `doc_${crypto.randomUUID()}`);
  if (!verifyVaultSignature(docId, req.query.expires || req.body.expires, req.query.signature || req.body.signature)) {
    res.status(403).json({ success: false, detail: 'Signed URL is invalid or expired.' });
    return;
  }
  const content = String(req.body.content_b64 || req.body.content || '');
  const metadata = {
    doc_id: docId,
    filename: String(req.body.filename || 'vault-document').slice(0, 180),
    type: String(req.body.type || 'document').slice(0, 80),
    size: Number(req.body.size || Buffer.byteLength(content)),
    user_id: cleanUserId(req.body.user_id),
    updated_at: new Date().toISOString()
  };
  docVault.set(docId, {
    metadata,
    encrypted: encryptVaultText(content)
  });
  res.json({
    success: true,
    doc_id: docId,
    encrypted: true,
    detail: 'Document content stored in encrypted backend memory scaffold. Replace with object storage and database metadata for production.'
  });
});

app.get('/vault/document/:doc_id', (req, res) => {
  const docId = cleanDocId(req.params.doc_id);
  if (!verifyVaultSignature(docId, req.query.expires, req.query.signature)) {
    res.status(403).json({ success: false, detail: 'Signed URL is invalid or expired.' });
    return;
  }
  const saved = docVault.get(docId);
  if (!saved) {
    res.status(404).json({ success: false, detail: 'Document not found.' });
    return;
  }
  res.json({
    success: true,
    metadata: saved.metadata,
    content_b64: saved.encrypted ? decryptVaultText(saved.encrypted) : null,
    encrypted_at_rest: Boolean(saved.encrypted)
  });
});

app.get('/app/state/:user_id', (req, res) => {
  const userId = cleanUserId(req.params.user_id);
  res.json({
    success: true,
    storage: 'memory-scaffold',
    detail: 'Replace this Map with Postgres/Supabase before production.',
    state: appStates.get(userId) || null
  });
});

app.post('/app/state', (req, res) => {
  const userId = cleanUserId(req.body.user_id);
  const state = req.body.state || {};
  appStates.set(userId, {
    state,
    updated_at: new Date().toISOString()
  });
  res.json({
    success: true,
    storage: 'memory-scaffold',
    detail: 'State saved to backend memory scaffold. Use a real database for production persistence.'
  });
});

app.use((req, res) => {
  res.status(404).json({ success: false, detail: 'Route not found.' });
});

app.listen(PORT, () => {
  console.log(`VaultFlow backend listening on port ${PORT}`);
});

function splitEnv(value) {
  return String(value || '')
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}

function plaidConfigured() {
  return Boolean(process.env.PLAID_CLIENT_ID && process.env.PLAID_SECRET);
}

function plaidHealthPayload() {
  const clientId = String(process.env.PLAID_CLIENT_ID || '').trim();
  const secret = String(process.env.PLAID_SECRET || '').trim();
  const configured = Boolean(clientId && secret);
  return {
    success: configured,
    configured,
    build_version: BUILD_VERSION,
    plaid_env: PLAID_ENV,
    client_id_present: Boolean(clientId),
    secret_present: Boolean(secret),
    products: PLAID_PRODUCTS,
    country_codes: PLAID_COUNTRY_CODES,
    detail: configured
      ? 'Plaid backend variables are present. If Link token creation fails, verify PLAID_CLIENT_ID and PLAID_SECRET are from the same Plaid environment.'
      : 'Missing PLAID_CLIENT_ID or PLAID_SECRET in backend environment variables.'
  };
}

function alpacaConfigured() {
  return Boolean(process.env.ALPACA_KEY_ID && process.env.ALPACA_SECRET_KEY);
}

function openaiConfigured() {
  return Boolean(OPENAI_API_KEY);
}

function alpacaPaperOrdersEnabled() {
  return process.env.ENABLE_ALPACA_PAPER_ORDERS === 'true';
}

function alpacaPaperTradingBase() {
  return ALPACA_TRADING_BASE_URL.includes('paper-api');
}

function alpacaLiveTradingEnabled() {
  return process.env.ENABLE_ALPACA_LIVE_TRADING === 'true';
}

function alpacaOrderExecutionEnabled() {
  return alpacaPaperTradingBase() ? alpacaPaperOrdersEnabled() : alpacaLiveTradingEnabled();
}

function cleanDocId(value) {
  return String(value || 'doc')
    .trim()
    .replace(/[^A-Za-z0-9_.-]/g, '')
    .slice(0, 120) || `doc_${crypto.randomUUID()}`;
}

function signVaultUrl(docId, expires) {
  return crypto
    .createHmac('sha256', DOC_VAULT_SECRET)
    .update(`${docId}:${expires}`)
    .digest('hex');
}

function verifyVaultSignature(docId, expires, signature) {
  const expiresNumber = Number(expires || 0);
  if (!expiresNumber || Date.now() > expiresNumber) return false;
  const expected = signVaultUrl(docId, expiresNumber);
  const actual = String(signature || '');
  if (expected.length !== actual.length) return false;
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(actual));
}

function docVaultKey() {
  return crypto.createHash('sha256').update(DOC_VAULT_SECRET).digest();
}

function encryptVaultText(value) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', docVaultKey(), iv);
  const encrypted = Buffer.concat([cipher.update(String(value || ''), 'utf8'), cipher.final()]);
  return {
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    data: encrypted.toString('base64')
  };
}

function decryptVaultText(record) {
  const decipher = crypto.createDecipheriv('aes-256-gcm', docVaultKey(), Buffer.from(record.iv, 'base64'));
  decipher.setAuthTag(Buffer.from(record.tag, 'base64'));
  return Buffer.concat([
    decipher.update(Buffer.from(record.data, 'base64')),
    decipher.final()
  ]).toString('utf8');
}

function requirePlaidConfig(req, res, next) {
  if (plaidConfigured()) {
    next();
    return;
  }
  res.status(500).json({
    success: false,
    detail: 'Plaid backend is missing PLAID_CLIENT_ID or PLAID_SECRET.'
  });
}

function normalizePlaidProducts(products) {
  const allowed = new Set(['auth', 'transactions', 'identity', 'assets', 'investments', 'liabilities']);
  return splitEnv(Array.isArray(products) ? products.join(',') : products)
    .map((product) => product.toLowerCase())
    .filter((product) => allowed.has(product));
}

function normalizeIncomeSourceTypes(value) {
  const requested = Array.isArray(value) ? value : splitEnv(value || 'payroll');
  const allowed = new Set(['payroll', 'document', 'bank']);
  const output = requested
    .map((item) => String(item || '').toLowerCase().trim())
    .filter((item) => allowed.has(item));
  return output.length ? output : ['payroll'];
}

async function getPlaidIncomeUserToken(userId) {
  const saved = incomeUsers.get(userId);
  if (saved && saved.userToken) return saved.userToken;
  const data = await plaidPost('/user/create', {
    client_user_id: userId
  });
  incomeUsers.set(userId, {
    userToken: data.user_token,
    userId: data.user_id,
    createdAt: new Date().toISOString()
  });
  return data.user_token;
}

function cleanUserId(value) {
  const raw = String(value || 'guest').trim();
  return raw.slice(0, 128) || 'guest';
}

function alpacaHeaders() {
  return {
    'Content-Type': 'application/json',
    'APCA-API-KEY-ID': process.env.ALPACA_KEY_ID,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
  };
}

async function alpacaGet(baseUrl, path) {
  const response = await fetch(`${baseUrl}${path}`, {
    method: 'GET',
    headers: alpacaHeaders()
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(data.message || data.detail || `Alpaca request failed: ${path}`);
    err.status = response.status;
    throw err;
  }
  return data;
}

async function alpacaPost(baseUrl, path, payload) {
  const response = await fetch(`${baseUrl}${path}`, {
    method: 'POST',
    headers: alpacaHeaders(),
    body: JSON.stringify(payload || {})
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(data.message || data.detail || `Alpaca request failed: ${path}`);
    err.status = response.status;
    throw err;
  }
  return data;
}

function alpacaTradingGet(path) {
  return alpacaGet(ALPACA_TRADING_BASE_URL, path);
}

function alpacaTradingPost(path, payload) {
  return alpacaPost(ALPACA_TRADING_BASE_URL, path, payload);
}

async function fetchAlpacaPriceMap(symbols) {
  const cleanSymbols = normalizeMarketSymbols(symbols).filter((symbol) => !symbol.includes('/') && !['BTC', 'ETH'].includes(symbol));
  if (!cleanSymbols.length) return {};
  const end = new Date();
  const start = new Date(end.getTime() - 220 * 24 * 60 * 60 * 1000);
  const params = new URLSearchParams({
    symbols: cleanSymbols.join(','),
    timeframe: '1Day',
    start: start.toISOString(),
    end: end.toISOString(),
    adjustment: 'all',
    feed: ALPACA_DATA_FEED,
    sort: 'asc',
    limit: '1000'
  });
  const data = await alpacaGet(ALPACA_DATA_BASE_URL, `/v2/stocks/bars?${params.toString()}`);
  const output = {};
  Object.entries(data.bars || {}).forEach(([symbol, bars]) => {
    const prices = (bars || [])
      .map((bar) => Number(bar.c || bar.close || 0))
      .filter((value) => Number.isFinite(value) && value > 0);
    if (prices.length >= 40) output[symbol.toUpperCase()] = prices.slice(-140);
  });
  return output;
}

async function plaidPost(path, payload) {
  const response = await fetch(`${PLAID_BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'PLAID-CLIENT-ID': process.env.PLAID_CLIENT_ID,
      'PLAID-SECRET': process.env.PLAID_SECRET,
      'Plaid-Version': PLAID_VERSION
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.error_code) {
    const err = new Error(data.error_message || data.display_message || `Plaid request failed: ${path}`);
    err.status = response.status;
    err.plaid = data;
    throw err;
  }
  return data;
}

function resolveBankSession(tokenOrSessionId) {
  const key = String(tokenOrSessionId || '').trim();
  if (!key) return null;
  const saved = bankSessions.get(key);
  if (saved) return saved;

  // Development escape hatch for older clients. Avoid sending raw Plaid
  // access tokens to browsers in production.
  if (key.startsWith('access-')) {
    return { accessToken: key, itemId: 'direct_access_token', cursor: null };
  }
  return null;
}

async function syncTransactions(session) {
  const transactions = [];
  let cursor = session.cursor || null;
  let hasMore = true;
  let requestId = null;

  while (hasMore && transactions.length < 500) {
    const data = await plaidPost('/transactions/sync', {
      access_token: session.accessToken,
      cursor,
      count: 100
    });
    requestId = data.request_id || requestId;
    transactions.push(...(data.added || []), ...(data.modified || []));
    cursor = data.next_cursor || cursor;
    hasMore = Boolean(data.has_more);
  }

  session.cursor = cursor;
  return { transactions, request_id: requestId };
}

async function getBalance(session) {
  const data = await plaidPost('/accounts/balance/get', {
    access_token: session.accessToken
  });
  const account = Array.isArray(data.accounts) ? data.accounts[0] : null;
  if (!account || !account.balances) return null;
  return account.balances.current;
}

function detectPaychecks(transactions) {
  return (transactions || [])
    .filter((tx) => {
      const amount = Number(tx.amount || 0);
      const name = String(tx.name || tx.merchant_name || '').toLowerCase();
      const category = Array.isArray(tx.category) ? tx.category.join(' ').toLowerCase() : '';
      const isDeposit = amount < 0;
      const looksLikePay =
        name.includes('payroll') ||
        name.includes('salary') ||
        name.includes('direct deposit') ||
        name.includes('maritime') ||
        name.includes('va deposit') ||
        name.includes('veterans') ||
        category.includes('payroll');
      return isDeposit && Math.abs(amount) >= 500 && looksLikePay;
    })
    .map((tx) => ({
      name: tx.name || tx.merchant_name || 'Deposit',
      amount: Math.abs(Number(tx.amount || 0)),
      date: tx.date || tx.authorized_date || null,
      transaction_id: tx.transaction_id
    }))
    .sort((a, b) => b.amount - a.amount);
}

function normalizeMarketSymbols(symbols) {
  const values = Array.isArray(symbols) ? symbols : String(symbols || 'SPY,QQQ').split(',');
  return values
    .map((symbol) => String(symbol || '').trim().toUpperCase().replace(/[^A-Z0-9.-]/g, ''))
    .filter(Boolean)
    .slice(0, 8);
}

function normalizeSignalSettings(settings = {}) {
  const strategy = ['balanced', 'momentum', 'conservative'].includes(settings.strategy)
    ? settings.strategy
    : 'balanced';
  const risk = ['low', 'medium', 'high'].includes(settings.risk) ? settings.risk : 'medium';
  const maxPosition = Math.max(25, Math.min(10000, Number(settings.maxPosition || 250)));
  return { strategy, risk, maxPosition };
}

function buildMarketSignals(symbols, settings, priceMap = {}) {
  return normalizeMarketSymbols(symbols).map((symbol) => {
    const prices = Array.isArray(priceMap[symbol]) && priceMap[symbol].length >= 40
      ? priceMap[symbol].slice(-140)
      : seededPrices(symbol, 120);
    const last = prices[prices.length - 1];
    const prev = prices[prices.length - 2] || last;
    const sma20 = average(prices.slice(-20));
    const sma50 = average(prices.slice(-50));
    const sma100 = average(prices.slice(-100));
    const rsi = calcRsi(prices, 14);
    const ema12 = emaSeries(prices, 12);
    const ema26 = emaSeries(prices, 26);
    const macdSeries = prices.map((_, index) => (ema12[index] || 0) - (ema26[index] || 0));
    const macd = macdSeries[macdSeries.length - 1];
    const macdSignalSeries = emaSeries(macdSeries, 9);
    const macdSignal = macdSignalSeries[macdSignalSeries.length - 1];
    const dailyReturns = priceReturns(prices);
    const dailyVol = standardDeviation(dailyReturns.slice(-30));
    const vol = dailyVol * Math.sqrt(252);
    const momentum = (last - (prices[prices.length - 21] || last)) / Math.max(0.01, prices[prices.length - 21] || last);
    const trendSlope = slopeScore(prices.slice(-30));
    const factors = [];
    let score = 0;

    if (last > sma20) {
      score += 1;
      factors.push('Price above SMA20');
    } else {
      score -= 1;
      factors.push('Below SMA20');
    }
    if (sma20 > sma50) {
      score += 1;
      factors.push('SMA20 above SMA50');
    }
    if (sma50 > sma100) {
      score += 1;
      factors.push('Long trend up');
    }
    if (macd > macdSignal) {
      score += 1;
      factors.push('MACD bullish');
    } else {
      score -= 1;
      factors.push('MACD weak');
    }
    if (momentum > 0.06) {
      score += 2;
      factors.push('Strong momentum');
    } else if (momentum > 0.02) {
      score += 1;
      factors.push('Positive momentum');
    } else if (momentum < -0.06) {
      score -= 2;
      factors.push('Momentum breakdown');
    } else if (momentum < -0.02) {
      score -= 1;
      factors.push('Momentum fading');
    }
    if (rsi < 32) {
      score += 2;
      factors.push('RSI oversold');
    } else if (rsi < 45) {
      score += 1;
      factors.push('RSI reset');
    } else if (rsi > 76) {
      score -= 2;
      factors.push('RSI overheated');
    } else if (rsi > 66) {
      score -= 1;
      factors.push('RSI extended');
    }
    if (trendSlope > 0.025) {
      score += 1;
      factors.push('30-day slope up');
    }
    if (settings.strategy === 'momentum') score += momentum > 0 ? 1 : -1;
    if (settings.strategy === 'conservative' && vol > 0.45) {
      score -= 1;
      factors.push('Volatility filter');
    }

    const risk = vol > 0.58 ? 'High' : vol > 0.28 ? 'Medium' : 'Low';
    if (settings.risk === 'low' && risk === 'High') score -= 2;
    if (settings.risk === 'high' && score > 0) score += 1;

    let signal = score >= 3 ? 'BUY' : score <= -3 ? 'SELL' : 'HOLD';
    if (settings.strategy === 'conservative' && risk === 'High' && signal === 'BUY') signal = 'HOLD';

    const confidence = clamp(52 + Math.abs(score) * 7 - (risk === 'High' ? 8 : 0) + (Math.abs(momentum) > 0.05 ? 4 : 0), 50, 96);
    const stopPct = clamp(dailyVol * 2.2, 0.025, 0.12);
    const targetPct = stopPct * (signal === 'SELL' ? 1.45 : 2.1);
    const stop = signal === 'SELL' ? last * (1 + stopPct) : last * (1 - stopPct);
    const target = signal === 'SELL' ? last * (1 - targetPct) : last * (1 + targetPct);
    const riskMultiplier = settings.risk === 'low' ? 0.45 : settings.risk === 'high' ? 1 : 0.7;
    const size = signal === 'BUY' ? Math.round(settings.maxPosition * (confidence / 100) * riskMultiplier * (risk === 'High' ? 0.65 : 1)) : 0;

    return {
      s: symbol,
      g: signal,
      label: signal === 'BUY' && score >= 6 ? 'STRONG BUY' : signal,
      score,
      r: Math.round(rsi),
      price: roundMoney(last),
      change: (last - prev) / Math.max(0.01, prev),
      sma20: roundMoney(sma20),
      sma50: roundMoney(sma50),
      sma100: roundMoney(sma100),
      macd,
      macdSignal,
      momentum,
      vol,
      risk,
      stop: roundMoney(stop),
      target: roundMoney(target),
      size,
      confidence: Math.round(confidence),
      source: priceMap[symbol] ? 'alpaca' : 'synthetic-fallback',
      factors: factors.slice(0, 5),
      reason:
        signal === 'BUY'
          ? 'Trend and momentum are strong enough for a paper-trade setup.'
          : signal === 'SELL'
            ? 'Risk model is defensive; paper buys are blocked.'
            : 'Mixed indicators. Wait for a cleaner setup.'
    };
  });
}

function seededPrices(symbol, count = 120) {
  let seed = 0;
  for (let i = 0; i < symbol.length; i += 1) seed += symbol.charCodeAt(i) * (i + 3);
  const upper = String(symbol || '').toUpperCase();
  const base = upper.startsWith('BTC') ? 64000 : upper.startsWith('ETH') ? 3400 : 80 + (seed % 180);
  let price = base;
  const prices = [];
  for (let day = 0; day < count; day += 1) {
    const wave = Math.sin((day + (seed % 17)) / 5) * 2.4 + Math.cos((day + (seed % 11)) / 9) * 1.5;
    const drift = ((seed % 9) - 4) * 0.045;
    const shock = day % 29 === 0 ? ((seed % 7) - 3) * 0.65 : 0;
    const scale = upper.startsWith('BTC') ? 110 : upper.startsWith('ETH') ? 12 : 1;
    price = Math.max(2, price + (wave * 0.38 + drift + shock) * scale);
    prices.push(roundMoney(price));
  }
  return prices;
}

function average(values) {
  return values.reduce((sum, value) => sum + value, 0) / Math.max(1, values.length);
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function roundMoney(value) {
  return Number(Number(value || 0).toFixed(2));
}

function priceReturns(prices) {
  const output = [];
  for (let index = 1; index < prices.length; index += 1) {
    output.push((prices[index] - prices[index - 1]) / Math.max(0.01, prices[index - 1]));
  }
  return output;
}

function standardDeviation(values) {
  if (!values.length) return 0;
  const mean = average(values);
  return Math.sqrt(average(values.map((value) => (value - mean) ** 2)));
}

function emaSeries(values, period) {
  const smoothing = 2 / (period + 1);
  const output = [];
  let ema = values[0] || 0;
  values.forEach((value, index) => {
    ema = index === 0 ? value : value * smoothing + ema * (1 - smoothing);
    output.push(ema);
  });
  return output;
}

function slopeScore(values) {
  const midpoint = Math.ceil(values.length / 2);
  const first = average(values.slice(0, midpoint));
  const second = average(values.slice(midpoint));
  return (second - first) / Math.max(0.01, first);
}

function calcRsi(prices, period) {
  let gains = 0;
  let losses = 0;
  const start = Math.max(1, prices.length - period);
  for (let index = start; index < prices.length; index += 1) {
    const change = prices[index] - prices[index - 1];
    if (change >= 0) gains += change;
    else losses -= change;
  }
  if (losses === 0) return 100;
  const rs = gains / period / (losses / period);
  return 100 - 100 / (1 + rs);
}

async function askOpenAIAdvisor({ message, history, context }) {
  const safeHistory = (history || [])
    .filter((entry) => entry && entry.text && entry.text !== 'Thinking...')
    .slice(-8)
    .map((entry) => `${entry.role === 'user' ? 'User' : 'Assistant'}: ${String(entry.text).slice(0, 1200)}`)
    .join('\n');
  const safeContext = sanitizeAssistantContext(context);
  const instructions = [
    'You are VaultFlow Assistant, a helpful AI CFO and customer support assistant inside a personal finance app.',
    'Answer real user questions naturally instead of using canned scripts.',
    'Use the provided VaultFlow context when it helps, but do not invent bank balances, trades, documents, or account connections.',
    'For investing, taxes, legal, credit, insurance, or real-money movement, give educational planning guidance and clearly say it is not professional advice.',
    'Never claim that a transfer, trade, subscription, or account change has been executed unless the backend context explicitly says it happened.',
    'If setup is missing, explain the next exact step in plain language.',
    'Keep answers concise, usually under 180 words, unless the user asks for detail.'
  ].join(' ');
  const input = [
    safeHistory ? `Recent conversation:\n${safeHistory}` : 'Recent conversation: none',
    `Current user question:\n${message}`,
    `VaultFlow context JSON:\n${JSON.stringify(safeContext, null, 2)}`
  ].join('\n\n');
  const response = await fetch(`${OPENAI_BASE_URL}/responses`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      instructions,
      input,
      max_output_tokens: 900
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(data.error && data.error.message ? data.error.message : `OpenAI request failed with status ${response.status}.`);
    err.status = response.status;
    throw err;
  }
  const text = extractOpenAIText(data);
  if (!text) throw new Error('OpenAI returned an empty response.');
  return text;
}

function sanitizeAssistantContext(context = {}) {
  const allowed = {
    page: context.page,
    plan: context.plan,
    bank_connected: Boolean(context.bank_connected),
    bank_kind: context.bank_kind,
    payday_detected: Boolean(context.payday_detected),
    last_paycheck_amount: Number(context.last_paycheck_amount || 0),
    local_preview: Boolean(context.local_preview),
    finance: sanitizeNumberObject(context.finance),
    assets: sanitizeNumberObject(context.assets),
    investment_total: Number(context.investment_total || 0),
    holdings_count: Number(context.holdings_count || 0),
    vault_docs_count: Number(context.vault_docs_count || 0),
    included_report_docs: Number(context.included_report_docs || 0),
    recent_signals: Array.isArray(context.recent_signals)
      ? context.recent_signals.slice(0, 5).map((signal) => ({
          symbol: String(signal.symbol || signal.s || '').slice(0, 12),
          signal: String(signal.signal || signal.g || '').slice(0, 16),
          confidence: Number(signal.confidence || 0),
          risk: String(signal.risk || '').slice(0, 20)
        }))
      : []
  };
  return allowed;
}

function sanitizeNumberObject(value) {
  if (!value || typeof value !== 'object') return {};
  const output = {};
  Object.entries(value).slice(0, 20).forEach(([key, raw]) => {
    if (typeof raw === 'number') output[key] = Number.isFinite(raw) ? raw : 0;
    else if (typeof raw === 'string' && raw.length < 80) output[key] = raw;
    else if (typeof raw === 'boolean') output[key] = raw;
  });
  return output;
}

function extractOpenAIText(data) {
  if (typeof data.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
  const chunks = [];
  (data.output || []).forEach((item) => {
    (item.content || []).forEach((part) => {
      if (typeof part.text === 'string') chunks.push(part.text);
      if (typeof part.output_text === 'string') chunks.push(part.output_text);
    });
  });
  return chunks.join('\n').trim();
}

function vaultflowAdvisorAnswer(message) {
  const q = String(message || '').toLowerCase();
  if (/alpaca|trade|stock|signal|algo/.test(q)) {
    return 'For accurate VaultFlow signals, add ALPACA_KEY_ID and ALPACA_SECRET_KEY to the backend, keep ALPACA_DATA_FEED=iex unless you have SIP access, then run Stock Algo. The backend will use Alpaca daily bars when available and fallback safely if data is missing. Paper orders only submit to Alpaca when ENABLE_ALPACA_PAPER_ORDERS=true and the signal is BUY.';
  }
  if (/wealth gps|next best|financial twin|digital twin|timeline|operating system|life os|super intelligence/.test(q)) {
    return 'VaultFlow is becoming a financial operating system: Wealth GPS ranks the highest-impact daily action, the Life Wealth Digital Twin simulates choices across decades, the Wealth Timeline maps future milestones, and Super Intelligence warns about cash-flow, debt, document, bank, and trading risks before they become expensive.';
  }
  if (/investment|brokerage|fidelity|vanguard|robinhood|coinbase|portfolio/.test(q)) {
    return 'Outside investment tracking should use Plaid Investments where supported, plus CSV/manual import for accounts that do not expose holdings. VaultFlow tracks holdings and net worth, but it should not trade outside brokerages from this app.';
  }
  if (/plaid|bank/.test(q)) {
    return 'Plaid keys belong in backend environment variables. Use Plaid Link for bank and investment connections, then store only the opaque VaultFlow session ID in the browser.';
  }
  return 'I can help with VaultFlow setup, Plaid, Alpaca, investment tracking, payday detection, budgets, debt payoff, goals, and reports. This assistant is educational and not financial advice.';
}

function sendPlaidError(res, err, fallback) {
  const plaid = err.plaid || {};
  const rawDetail = plaid.error_message || plaid.display_message || err.message || fallback;
  const detail = normalizePlaidErrorDetail(rawDetail, plaid);
  res.status(err.status || 500).json({
    success: false,
    detail,
    action: plaidErrorAction(rawDetail, plaid),
    error_code: plaid.error_code,
    error_type: plaid.error_type,
    request_id: plaid.request_id
  });
}

function normalizePlaidErrorDetail(message, plaid) {
  const text = String(message || '');
  const code = String(plaid.error_code || '');
  const lower = `${text} ${code}`.toLowerCase();
  if (lower.includes('invalid client_id') || lower.includes('invalid_api_keys') || lower.includes('invalid api keys')) {
    return 'Plaid rejected the backend key pair. In Railway, verify PLAID_CLIENT_ID is the Plaid Client ID and PLAID_SECRET is the Sandbox secret when PLAID_ENV=sandbox. Save variables and redeploy.';
  }
  if (lower.includes('environment') || lower.includes('secret')) {
    return `${text} Verify PLAID_ENV, PLAID_CLIENT_ID, and PLAID_SECRET all come from the same Plaid environment.`;
  }
  return text || 'Plaid request failed.';
}

function plaidErrorAction(message, plaid) {
  const lower = `${message || ''} ${plaid.error_code || ''}`.toLowerCase();
  if (lower.includes('invalid client_id') || lower.includes('invalid_api_keys') || lower.includes('invalid api keys')) {
    return 'Open Railway Variables, set PLAID_CLIENT_ID, PLAID_SECRET, and PLAID_ENV=sandbox from the Plaid Dashboard Sandbox keys, then redeploy the backend.';
  }
  return 'Check Plaid Dashboard keys, Railway variables, and backend deploy logs.';
}
